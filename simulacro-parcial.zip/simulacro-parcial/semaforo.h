#ifndef _SEMAFORO
#define _SEMAFORO


int creo_semaforo(void);
void inicia_semaforo(int, int);
void levanta_semaforo(int);
void espera_semaforo(int);

#endif