#include "global.h"
#include "semaforo.h"
#include "def.h"

extern int id_semaforo;
const char filename[CHAR_LEN] = "aviones.txt";
