#ifndef _GLOBAL
#define _GLOBAL
#include "def.h"

extern int id_semaforo;
const char filename;

#endif